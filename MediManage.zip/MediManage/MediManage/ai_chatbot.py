import streamlit as st
import json
import os
from datetime import datetime, timedelta
from typing import Dict, List, Optional
import pandas as pd

# Check if OpenAI is available
try:
    from openai import OpenAI
    OPENAI_AVAILABLE = True
except ImportError:
    OpenAI = None
    OPENAI_AVAILABLE = False

class PharmaceuticalChatbot:
    def __init__(self, db):
        self.db = db
        self.openai_client = None
        if OPENAI_AVAILABLE and os.environ.get("OPENAI_API_KEY"):
            self.openai_client = OpenAI(api_key=os.environ.get("OPENAI_API_KEY"))
            
        # Initialize conversation history
        if 'chat_history' not in st.session_state:
            st.session_state.chat_history = []
            
        # Predefined responses for common queries when OpenAI is not available
        self.fallback_responses = {
            "inventory": "I can help you check current inventory levels, low stock items, and expiring drugs.",
            "drug_info": "I can provide basic information about drugs in your inventory including dosage, category, and supplier details.",
            "interactions": "I can check for potential drug interactions using our built-in interaction database.",
            "ordering": "I can suggest items to reorder based on consumption patterns and current stock levels.",
            "expiry": "I can show you items nearing expiry and suggest actions to prevent wastage.",
            "analytics": "I can provide insights from your inventory data including trends and forecasts."
        }
    
    def get_system_context(self) -> str:
        """Get current system context for the AI"""
        try:
            # Get current inventory stats
            inventory_df = self.db.get_inventory()
            total_items = len(inventory_df)
            low_stock_items = len(inventory_df[inventory_df['current_stock'] < inventory_df['min_stock_level']])
            
            # Get expiring items
            expiring_items = self.db.get_expiring_drugs(days_ahead=30)
            
            # Get recent transactions
            recent_transactions = self.db.get_recent_transactions(limit=5)
            
            context = f"""
You are an AI assistant for a pharmaceutical inventory management system. Here's the current system status:

INVENTORY OVERVIEW:
- Total items in inventory: {total_items}
- Items with low stock: {low_stock_items}
- Items expiring in next 30 days: {len(expiring_items)}

RECENT ACTIVITY:
- Last {len(recent_transactions)} transactions recorded

You can help users with:
1. Inventory queries (stock levels, item details, categories)
2. Drug information and interactions
3. Reordering suggestions and supplier information
4. Expiry management and wastage prevention
5. Analytics and insights from inventory data
6. General pharmaceutical knowledge

Always provide accurate, helpful responses focused on pharmaceutical inventory management.
"""
            return context
        except Exception as e:
            return "You are an AI assistant for a pharmaceutical inventory management system."
    
    def query_inventory_data(self, query: str) -> Dict:
        """Query the database for relevant information based on user query"""
        try:
            results = {}
            query_lower = query.lower()
            
            # Check if query is about specific drug
            if any(word in query_lower for word in ['drug', 'medicine', 'medication', 'tablet', 'capsule']):
                inventory_df = self.db.get_inventory()
                # Simple keyword search in drug names
                words = query_lower.split()
                drug_matches = []
                for _, drug in inventory_df.iterrows():
                    drug_name_lower = drug['drug_name'].lower()
                    if any(word in drug_name_lower for word in words):
                        drug_matches.append(drug.to_dict())
                
                if drug_matches:
                    results['matching_drugs'] = drug_matches[:5]  # Limit to 5 matches
            
            # Check if query is about stock levels
            if any(word in query_lower for word in ['stock', 'level', 'quantity', 'low', 'empty']):
                inventory_df = self.db.get_inventory()
                low_stock = inventory_df[inventory_df['current_stock'] < inventory_df['min_stock_level']]
                results['low_stock_items'] = low_stock.to_dict('records')[:10]
            
            # Check if query is about expiry
            if any(word in query_lower for word in ['expiry', 'expire', 'expiring', 'expired']):
                expiring_items = self.db.get_expiring_drugs(days_ahead=30)
                results['expiring_items'] = expiring_items[:10]
            
            # Check if query is about transactions
            if any(word in query_lower for word in ['transaction', 'sale', 'purchase', 'recent']):
                recent_transactions = self.db.get_recent_transactions(limit=10)
                results['recent_transactions'] = recent_transactions.to_dict('records')
            
            return results
        except Exception as e:
            return {'error': str(e)}
    
    def generate_ai_response(self, user_message: str) -> str:
        """Generate AI response using OpenAI or fallback responses"""
        if not self.openai_client:
            return self.generate_fallback_response(user_message)
        
        try:
            # Get current system context
            system_context = self.get_system_context()
            
            # Query relevant data
            data_context = self.query_inventory_data(user_message)
            
            # Prepare context for AI
            context_message = f"{system_context}\n\nRELEVANT DATA:\n{json.dumps(data_context, indent=2, default=str)}"
            
            # Create messages for OpenAI
            messages = [
                {"role": "system", "content": context_message},
                {"role": "user", "content": user_message}
            ]
            
            # Add recent conversation history for context (last 3 exchanges)
            recent_history = st.session_state.chat_history[-6:]
            for msg in recent_history:
                if msg["role"] in ["user", "assistant"]:
                    messages.append({
                        "role": msg["role"],
                        "content": str(msg["content"])
                    })
            
            # the newest OpenAI model is "gpt-5" which was released August 7, 2025.
            # do not change this unless explicitly requested by the user
            response = self.openai_client.chat.completions.create(
                model="gpt-5",
                messages=messages,
                max_tokens=500,
                temperature=0.7
            )
            
            return response.choices[0].message.content or "I apologize, but I couldn't generate a response."
            
        except Exception as e:
            st.error(f"AI response error: {str(e)}")
            return self.generate_fallback_response(user_message)
    
    def generate_fallback_response(self, user_message: str) -> str:
        """Generate fallback response when OpenAI is not available"""
        user_message_lower = user_message.lower()
        
        # Query relevant data
        data_context = self.query_inventory_data(user_message)
        
        # Check what type of query this is and provide appropriate response
        if any(word in user_message_lower for word in ['stock', 'level', 'inventory']):
            if 'low_stock_items' in data_context and data_context['low_stock_items']:
                items = data_context['low_stock_items']
                response = f"I found {len(items)} items with low stock:\n\n"
                for item in items[:5]:
                    response += f"• {item['drug_name']}: {item['current_stock']} units (min: {item['min_stock_level']})\n"
                return response
            else:
                return "All items appear to be adequately stocked. No low stock alerts at the moment."
        
        elif any(word in user_message_lower for word in ['expiry', 'expire', 'expiring']):
            if 'expiring_items' in data_context and data_context['expiring_items']:
                items = data_context['expiring_items']
                response = f"I found {len(items)} items expiring soon:\n\n"
                for item in items[:5]:
                    response += f"• {item['drug_name']} (Batch: {item['batch_number']}) - Expires: {item['expiry_date']}\n"
                return response
            else:
                return "No items are expiring in the next 30 days."
        
        elif any(word in user_message_lower for word in ['drug', 'medicine', 'medication']):
            if 'matching_drugs' in data_context and data_context['matching_drugs']:
                items = data_context['matching_drugs']
                response = f"I found {len(items)} matching drugs:\n\n"
                for item in items[:3]:
                    response += f"• {item['drug_name']} - Stock: {item['current_stock']} units - Price: ₹{item['unit_price']:.2f}\n"
                return response
            else:
                return "I couldn't find any matching drugs in the current inventory."
        
        elif any(word in user_message_lower for word in ['transaction', 'sale', 'recent']):
            if 'recent_transactions' in data_context and data_context['recent_transactions']:
                transactions = data_context['recent_transactions']
                response = f"Recent transactions:\n\n"
                for txn in transactions[:5]:
                    response += f"• {txn['transaction_type']}: {txn['drug_name']} - Qty: {txn['quantity']} - ₹{txn['total_amount']:.2f}\n"
                return response
            else:
                return "No recent transactions found."
        
        else:
            return "I'm here to help with your pharmaceutical inventory management. Ask me about stock levels, expiring items, drug information, or recent transactions!"
    
    def add_to_history(self, role: str, content: str):
        """Add message to conversation history"""
        st.session_state.chat_history.append({
            "role": role,
            "content": content,
            "timestamp": datetime.now()
        })
        
        # Keep only last 20 messages to manage memory
        if len(st.session_state.chat_history) > 20:
            st.session_state.chat_history = st.session_state.chat_history[-20:]
    
    def get_suggested_questions(self) -> List[str]:
        """Get suggested questions based on current inventory state"""
        try:
            suggestions = []
            
            # Check for low stock items
            inventory_df = self.db.get_inventory()
            low_stock_items = len(inventory_df[inventory_df['current_stock'] < inventory_df['min_stock_level']])
            if low_stock_items > 0:
                suggestions.append("Which items are running low on stock?")
            
            # Check for expiring items
            expiring_items = self.db.get_expiring_drugs(days_ahead=30)
            if len(expiring_items) > 0:
                suggestions.append("What medications are expiring soon?")
            
            # Always available suggestions
            suggestions.extend([
                "Show me the most expensive items in inventory",
                "What are my recent transactions?",
                "Which suppliers do I order from most?",
                "What's the total value of my inventory?"
            ])
            
            return suggestions[:6]  # Return max 6 suggestions
            
        except Exception as e:
            return ["How can I help you with your inventory today?"]

def render_ai_chatbot_page(db):
    """Render the AI chatbot page"""
    st.title("🤖 AI Pharmaceutical Assistant")
    st.markdown("Ask me anything about your pharmaceutical inventory, drug information, or system insights!")
    
    # Initialize chatbot
    chatbot = PharmaceuticalChatbot(db)
    
    # Check if OpenAI is available
    if not OPENAI_AVAILABLE or not os.environ.get("OPENAI_API_KEY"):
        st.info("💡 **Enhanced AI Features Available**: Connect your OpenAI API key for advanced conversational capabilities and detailed pharmaceutical insights!")
        with st.expander("ℹ️ How to enable advanced AI features"):
            st.markdown("""
            1. Get an OpenAI API key from [OpenAI Platform](https://platform.openai.com)
            2. Add it to your Replit secrets as `OPENAI_API_KEY`
            3. Restart the application to enable advanced AI features
            
            Even without OpenAI, I can still help with basic inventory queries using your database!
            """)
    
    # Suggested questions
    st.subheader("💡 Suggested Questions")
    suggestions = chatbot.get_suggested_questions()
    
    cols = st.columns(2)
    for i, suggestion in enumerate(suggestions):
        col = cols[i % 2]
        if col.button(suggestion, key=f"suggestion_{i}"):
            # Add suggestion to chat
            chatbot.add_to_history("user", suggestion)
            # Get and add response
            response = chatbot.generate_ai_response(suggestion)
            chatbot.add_to_history("assistant", response)
            st.rerun()
    
    st.divider()
    
    # Chat interface
    st.subheader("💬 Chat with AI Assistant")
    
    # Display chat history
    chat_container = st.container()
    with chat_container:
        for i, message in enumerate(st.session_state.chat_history):
            if message["role"] == "user":
                with st.chat_message("user"):
                    st.write(message["content"])
            else:
                with st.chat_message("assistant"):
                    st.write(message["content"])
    
    # Chat input
    if prompt := st.chat_input("Ask me about your pharmaceutical inventory..."):
        # Add user message to history
        chatbot.add_to_history("user", prompt)
        
        # Display user message
        with st.chat_message("user"):
            st.write(prompt)
        
        # Generate and display assistant response
        with st.chat_message("assistant"):
            with st.spinner("Thinking..."):
                response = chatbot.generate_ai_response(prompt)
                st.write(response)
                
                # Add assistant response to history
                chatbot.add_to_history("assistant", response)
    
    # Chat controls
    st.sidebar.markdown("### 🛠️ Chat Controls")
    if st.sidebar.button("🗑️ Clear Chat History"):
        st.session_state.chat_history = []
        st.rerun()
    
    # Chat statistics
    if st.session_state.chat_history:
        st.sidebar.markdown(f"**Messages:** {len(st.session_state.chat_history)}")
        st.sidebar.markdown(f"**Conversation started:** {st.session_state.chat_history[0]['timestamp'].strftime('%H:%M')}")
    
    # Quick actions
    st.sidebar.markdown("### ⚡ Quick Actions")
    if st.sidebar.button("📊 Current Inventory Status"):
        status_query = "Give me a summary of my current inventory status"
        chatbot.add_to_history("user", status_query)
        response = chatbot.generate_ai_response(status_query)
        chatbot.add_to_history("assistant", response)
        st.rerun()
    
    if st.sidebar.button("⚠️ Check Alerts"):
        alerts_query = "What alerts or issues should I be aware of?"
        chatbot.add_to_history("user", alerts_query)
        response = chatbot.generate_ai_response(alerts_query)
        chatbot.add_to_history("assistant", response)
        st.rerun()